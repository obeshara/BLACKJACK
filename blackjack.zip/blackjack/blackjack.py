import random
import os
import sys
import pygame
from pygame.locals import *
pygame.font.init()
pygame.mixer.init()
screen = pygame.display.set_mode((1200, 800))
clock = pygame.time.Clock()

#--------------------Loading images, sounds, and displays----------------------
def LoadingTheImage(name, card):
    if card == 1:
        fullname = os.path.join("images/cards/", name)
    else:
        fullname = os.path.join('images', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error, message:
        print 'Image cannot be loaded:', name
        raise SystemExit, message
    image = image.convert()
    return image, image.get_rect()
        
def LoadingTheSound(name):
    fullName = os.path.join('sounds', name)
    try:
        sound = pygame.mixer.Sound(fullName)
    except pygame.error, message:
        print 'Sound cannot be loaded:', name
        raise SystemExit, message
    return sound

def playClickSound():
    clickSound = LoadingTheSound("click2.wav")
    clickSound.play()

def display(font, sentence):
    displayFont = pygame.font.Font.render(font, sentence, 1, (255,255,0)) 
    return displayFont

#--------------------------FUNCTIONS FOR LOGIC OF THE GAME----------------------
def mainGame():
    #function that executes when player's funds are zero
    def gameOver():
        while True:
            for event in pygame.event.get():
                if event.type == QUIT:
                    sys.exit()
                if event.type == KEYDOWN and event.key == K_ESCAPE:
                    sys.exit()
            screen.fill((0,0,0))
            
            #Displays game over on the screen
            oFont = pygame.font.Font(None, 50)
            displayFont = pygame.font.Font.render(oFont, "Game Over, you have no more funds", 1, (255,255,255)) 
            screen.blit(displayFont, (500, 500))
            
            #updates the screen
            pygame.display.flip()

    #function for shuffling the deck using Fisher-Yates algorithm
    def shufflingTheDeck(deck):
        n = len(deck) - 1
        while n > 0:
            k = random.randint(0, n)
            deck[k], deck[n] = deck[n], deck[k]
            n -= 1
        return deck

    #Function that makes the deck        
    def creatingTheDeck():
        #setting a list for symbolical cards
        deck = ['sj', 'sq', 'sk', 'sa','hj', 'hq', 'hk', 'ha',
                'dj', 'dq', 'dk', 'da','cj', 'cq', 'ck', 'ca']
        values = range(2,11)
        for x in values:
            spades = "s" + str(x)
            hearts = "h" + str(x)
            clubs = "c" + str(x)
            diamonds = "d" + str(x)
            deck.append(spades)
            deck.append(hearts)
            deck.append(clubs)
            deck.append(diamonds)
        return deck             

    def renewCards(deck, oldDeck):
        #Removes the cards from the old deck to the deck on the table after the deck in play is empty
        for card in oldDeck:
            deck.append(card)
        del oldDeck[:]
        deck = shufflingTheDeck(deck)
        return deck, oldDeck


    #After shuffling the deck, this function takes the top four cards and gives them to dealer and player accordingly    
    def dealingTheDeck(deck, oldDeck):
        deck = shufflingTheDeck(deck)
        dealerHand, playerHand = [], []
        cardsToDeal = 4
        while cardsToDeal > 0:
            if len(deck) == 0:
                deck, oldDeck = renewCards(deck, oldDeck)
# deal the first card to the player, second to dealer, 3rd to player, 4th to dealer, based on divisibility (it starts at 4, so it's even first)
            if cardsToDeal % 2 == 0: playerHand.append(deck[0])
            else: dealerHand.append(deck[0])
            
            del deck[0]
            cardsToDeal -= 1
            
        return deck, oldDeck, playerHand, dealerHand

#gives a card to the dealer or player after checking if the current deck is empty
    def hit(deck, oldDeck, hand):
        # if the deck is empty, shuffle in the dead deck
        if len(deck) == 0:
            deck, oldDeck = renewCards(deck, oldDeck)
        hand.append(deck[0])
        del deck[0]
        return deck, oldDeck, hand
    
#Function that checks what each player's cards are(value)
    def checkingHands(hand):
        totalValue = 0
        for card in hand:
            value = card[1:]
    # Jacks, kings and queens are all worth 10, and ace is worth 11    
            if value == 'j' or value == 'q' or value == 'k':
                value = 10
            elif value == 'a':
                value = 11
            else:
                value = int(value)
            totalValue += value
        if totalValue > 21:
            for card in hand:
                # If the player would bust and he has an ace in his hand, the ace's value is diminished by 10    
                # In situations where there are multiple aces in the hand, this checks to see if the total value
                # would still be over 21 if the second ace wasn't changed to a value of one. If it's under 21, there's no need 
                # to change the value of the second ace, so the loop breaks. 
                if card[1] == 'a':
                    totalValue -= 10
                if totalValue <= 21:
                    break
                else:
                    continue

        return totalValue
        
#Function that creates the different conditions for a blackjack
    def blackJack(deck, oldDeck, playerHand, dealerHand, funds, bet, cards, cardSprite):
        textFont = pygame.font.Font(None, 28)
        playerValue = checkingHands(playerHand)
        dealerValue = checkingHands(dealerHand)

        #Tie, in which case no money is lost and a new round starts
        if playerValue == 21 and dealerValue == 21:
            displayFont = display(textFont, "Tie with the dealer!")
            deck, playerHand, dealerHand, oldDeck, funds, roundEnd = endingTheRound(deck, playerHand, dealerHand, oldDeck, funds, 0, bet, cards, cardSprite)

        #User wins and receives money   
        elif playerValue == 21 and dealerValue != 21:
            displayFont = display(textFont, "Blackjack! You won $%.2f." %(bet*1.5))
            deck, playerHand, dealerHand, oldDeck, funds, roundEnd = endingTheRound(deck, playerHand, dealerHand, oldDeck, funds, bet, 0, cards, cardSprite)

        #Dealer wins and user loses money, new round starts   
        elif dealerValue == 21 and playerValue != 21:
            deck, playerHand, dealerHand, oldDeck, funds, roundEnd = endingTheRound(deck, playerHand, dealerHand, oldDeck, funds, 0, bet, cards, cardSprite)
            displayFont = display(textFont, "Dealer got blackjack! You lost $%.2f." %(bet))
        return displayFont, playerHand, dealerHand, oldDeck, funds, roundEnd

#Function for when the user draws too many cards
    def tooManyCards(deck, playerHand, dealerHand, oldDeck, funds, moneyGained, moneyLost, cards, cardSprite):   
        font = pygame.font.Font(None, 28)
        displayFont = display(font, "You drew too many cards! You lost $%.2f." %(moneyLost))
        deck, playerHand, dealerHand, oldDeck, funds, roundEnd = endingTheRound(deck, playerHand, dealerHand, oldDeck, funds, moneyGained, moneyLost, cards, cardSprite)
        return deck, playerHand, dealerHand, oldDeck, funds, roundEnd, displayFont

    def endingTheRound(deck, playerHand, dealerHand, oldDeck, funds, moneyGained, moneyLost, cards, cardSprite):
        #Called at the end of a round to determine what happens to the cards, the moneyz gained or lost,
        #and such. It also shows the dealer's hand to the player, by deleting the old sprites and showing all the cards.
    
        if len(playerHand) == 2 and "a" in playerHand[0] or "a" in playerHand[1]:
            # If the player has blackjack, pay his bet back 3:2
            moneyGained += (moneyGained/2.0)
            
    # Remove old dealer's cards
        cards.empty()
        dCardPos = (50, 70)
        for x in dealerHand:
            card = cardSprite(x, dCardPos)
            dCardPos = (dCardPos[0] + 80, dCardPos [1])
            cards.add(card)

    #Remove the cards from the player's and dealer's hands
        for card in playerHand:
            oldDeck.append(card)
        for card in dealerHand:
            oldDeck.append(card)

        del playerHand[:]
        del dealerHand[:]

        funds += moneyGained
        funds -= moneyLost
        
        textFont = pygame.font.Font(None, 28)
        
        if funds <= 0:
            gameOver()  
        
        roundEnd = 1
        return deck, playerHand, dealerHand, oldDeck, funds, roundEnd 
        
#Function that compares the hands
    def comparingHands(deck, oldDeck, playerHand, dealerHand, funds, bet, cards, cardSprite):
        
        textFont = pygame.font.Font(None, 28)
        # How much money the player loses or gains, default at 0, changed depending on outcome
        moneyGained = 0
        moneyLost = 0

        dealerValue = checkingHands(dealerHand)
        playerValue = checkingHands(playerHand)
            
        # Dealer hits until he has 17 or over        
        while True:
            if dealerValue < 17:
                # dealer hits when he has less than 17, and stands if he has 17 or above
                deck, oldDeck, dealerHand = hit(deck, oldDeck, dealerHand)
                dealerValue = checkingHands(dealerHand)
            else:   
                # dealer stands
                break
            
        if playerValue > dealerValue and playerValue <= 21:
            # Player has beaten the dealer, and hasn't busted, therefore WINS
            moneyGained = bet
            deck, playerHand, dealerHand, oldDeck, funds, roundEnd = endingTheRound(deck, playerHand, dealerHand, oldDeck, funds, bet, 0, cards, cardSprite)
            displayFont = display(textFont, "You won $%.2f." %(bet))
        elif playerValue == dealerValue and playerValue <= 21:
            # Tie
            deck, playerHand, dealerHand, oldDeck, funds, roundEnd = endingTheRound(deck, playerHand, dealerHand, oldDeck, funds, 0, 0, cards, cardSprite)
            displayFont = display(textFont, "It's a tie!")
        elif dealerValue > 21 and playerValue <= 21:
            # Dealer has busted and player hasn't
            deck, playerHand, dealerHand, oldDeck, funds, roundEnd = endingTheRound(deck, playerHand, dealerHand, oldDeck, funds, bet, 0, cards, cardSprite)
            displayFont = display(textFont, "Dealer busts! You won $%.2f." %(bet))
        else:
            # Dealer wins in every other siutation taht i can think of
            deck, playerHand, dealerHand, oldDeck, funds, roundEnd = endingTheRound(deck, playerHand, dealerHand, oldDeck, funds, 0, bet, cards, cardSprite)
            displayFont = display(textFont, "Dealer wins! You lost $%.2f." %(bet))
            
        return deck, oldDeck, roundEnd, funds, displayFont
    
#--------------------------SPRITE AND CLASS FUNCTIONS BEGIN-------------------------------
#Class for displaying card accordingly
    class cardSprite(pygame.sprite.Sprite):    
        def __init__(self, card, position):
            pygame.sprite.Sprite.__init__(self)
            cardImage = card + ".png"
            self.image, self.rect = LoadingTheImage(cardImage, 1)
            self.position = position
        def update(self):
            self.rect.center = self.position
            
#Class for hit button that allows the user to draw a card
    class hitButton(pygame.sprite.Sprite):      
        def __init__(self):
            pygame.sprite.Sprite.__init__(self)
            self.image, self.rect = LoadingTheImage("framedHitV2.jpg", 0)
            self.position = (800, 600)
            
    #Checks if round is not over after hitting the button, gives the player a new card and creates sprite for it 
        def update(self, mX, mY, deck, oldDeck, playerHand, cards, pCardPos, roundEnd, cardSprite, click):
            
            if roundEnd == 0:
                self.image, self.rect = LoadingTheImage("framedHitV2.jpg", 0)
            else:
                self.image, self.rect = LoadingTheImage("framedHitV2.jpg", 0)
            
            self.position = (800, 600)
            self.rect.center = self.position
            
            if self.rect.collidepoint(mX, mY) == 1 and click == 1:
                if roundEnd == 0: 
                    playClickSound()
                    deck, oldDeck, playerHand = hit(deck, oldDeck, playerHand)

                    currentCard = len(playerHand) - 1
                    card = cardSprite(playerHand[currentCard], pCardPos)
                    cards.add(card)
                    pCardPos = (pCardPos[0] - 80, pCardPos[1])
                
                    click = 0
                
            return deck, oldDeck, playerHand, pCardPos, click
            
#Class for stand button that allows the player not to draw cards anymore
    class standButton(pygame.sprite.Sprite):    
        def __init__(self):
            pygame.sprite.Sprite.__init__(self)
            self.image, self.rect = LoadingTheImage("framedStandV2.jpg", 0)
            self.position = (600, 600)
            
    #Checks if round is not over after hitting the button, then lets the player stand
        def update(self, mX, mY, deck, oldDeck, playerHand, dealerHand, cards, pCardPos, roundEnd, cardSprite, funds, bet, displayFont):
            if roundEnd == 0:
                self.image, self.rect = LoadingTheImage("framedStandV2.jpg", 0)
            else:
                self.image, self.rect = LoadingTheImage("framedStandV2.jpg", 0)
            
            self.position = (600, 600)
            self.rect.center = self.position
            
            if self.rect.collidepoint(mX, mY) == 1:
                if roundEnd == 0: 
                    playClickSound()
                    deck, oldDeck, roundEnd, funds, displayFont = comparingHands(deck, oldDeck, playerHand, dealerHand, funds, bet, cards, cardSprite)
                
            return deck, oldDeck, roundEnd, funds, playerHand, oldDeck, pCardPos, displayFont 
            
#Function for the double button that allows the player to hit while doubling his bet
    class doubleButton(pygame.sprite.Sprite):    
        def __init__(self):
            pygame.sprite.Sprite.__init__(self)
            self.image, self.rect = LoadingTheImage("framedDoubleV2.jpg", 0)
            self.position = (1000, 600)
            
        def update(self, mX, mY,   deck, oldDeck, playerHand, dealerHand, playerCards, cards, pCardPos, roundEnd, cardSprite, funds, bet, displayFont):
        
            """ If the button is clicked and the round is NOT over, let the player stand (take no more cards). """
            
            if roundEnd == 0 and funds >= bet * 2 and len(playerHand) == 2: self.image, self.rect = LoadingTheImage("framedDoubleV2.jpg", 0)
            else: self.image, self.rect = LoadingTheImage("framedDoubleV2.jpg", 0)
                
            self.position = (1000, 600)
            self.rect.center = self.position
                
            if self.rect.collidepoint(mX, mY) == 1:
                if roundEnd == 0 and funds >= bet * 2 and len(playerHand) == 2: 
                    bet = bet * 2
                    
                    playClickSound()
                    deck, oldDeck, playerHand = hit(deck, oldDeck, playerHand)

                    currentCard = len(playerHand) - 1
                    card = cardSprite(playerHand[currentCard], pCardPos)
                    playerCards.add(card)
                    pCardPos = (pCardPos[0] - 80, pCardPos[1])
        
                    deck, oldDeck, roundEnd, funds, displayFont = comparingHands(deck, oldDeck, playerHand, dealerHand, funds, bet, cards, cardSprite)
                    
                    bet = bet / 2

            return deck, oldDeck, roundEnd, funds, playerHand, oldDeck, pCardPos, displayFont, bet

#Class for deal button that starts new round
    class dealButton(pygame.sprite.Sprite):        
        def __init__(self):
            pygame.sprite.Sprite.__init__(self)
            self.image, self.rect = LoadingTheImage("framedDeal.jpg", 0)
            self.position = (400, 600)

        def update(self, mX, mY, deck, oldDeck, roundEnd, cardSprite, cards, playerHand, dealerHand, dCardPos, pCardPos, displayFont, playerCards, click, handsPlayed):
            
            # Get rid of the in between-hands chatter
            textFont = pygame.font.Font(None, 28)
            
            if roundEnd == 1: self.image, self.rect = LoadingTheImage("framedDeal.jpg", 0)
            else: self.image, self.rect = LoadingTheImage("framedDeal.jpg", 0)
            
            self.position = (400, 600)
            self.rect.center = self.position
            
                
            if self.rect.collidepoint(mX, mY) == 1:
                if roundEnd == 1 and click == 1:
                    playClickSound()
                    displayFont = display(textFont, "")
                    
                    cards.empty()
                    playerCards.empty()
                    
                    deck, oldDeck, playerHand, dealerHand = dealingTheDeck(deck, oldDeck)

                    dCardPos = (50, 70)
                    pCardPos = (540,370)

                    # Create player's card sprites
                    for x in playerHand:
                        card = cardSprite(x, pCardPos)
                        pCardPos = (pCardPos[0] - 80, pCardPos [1])
                        playerCards.add(card)
                    
                    # Create dealer's card sprites  
                    faceDownCard = cardSprite("back", dCardPos)
                    dCardPos = (dCardPos[0] + 80, dCardPos[1])
                    cards.add(faceDownCard)

                    card = cardSprite(dealerHand [0], dCardPos)
                    cards.add(card)
                    roundEnd = 0
                    click = 0
                    handsPlayed += 1
            return deck, oldDeck, playerHand, dealerHand, dCardPos, pCardPos, roundEnd, displayFont, click, handsPlayed
            
#Class for button that increases bet between hands          
    class plusButton(pygame.sprite.Sprite):
        def __init__(self):
            pygame.sprite.Sprite.__init__(self)
            self.image, self.rect = LoadingTheImage("plusbutton.jpg", 0)
            self.position = (1060, 400)
            
        def update(self, mX, mY, bet, funds, click, roundEnd):
            if roundEnd == 1: self.image, self.rect = LoadingTheImage("plusbutton.jpg", 0)
            else: self.image, self.rect = LoadingTheImage("plusbutton.jpg", 0)
            
            self.position = (1060, 400)
            self.rect.center = self.position
            
            if self.rect.collidepoint(mX, mY) == 1 and click == 1 and roundEnd == 1:
                playClickSound()
                    
                if bet < funds:
                    bet += 5.0
                    # If the bet is not a multiple of 5, turn it into a multiple of 5
                    # This can only happen when the player has gotten blackjack, and has funds that are not divisible by 5,
                    # then loses money, and has a bet higher than his funds, so the bet is pulled down to the funds, which are uneven.
                    # Whew!
                    if bet % 5 != 0:
                        while bet % 5 != 0:
                            bet -= 1

                click = 0
            
            return bet, click
            
#Class for button that decreases bets between hands
    class minusButton(pygame.sprite.Sprite): 
        def __init__(self):
            pygame.sprite.Sprite.__init__(self)
            self.image, self.rect = LoadingTheImage("minusbutton.jpg", 0)
            self.position = (1130, 400)
            
        def update(self, mX, mY, bet, click, roundEnd):  
            if roundEnd == 1: self.image, self.rect = LoadingTheImage("minusbutton.jpg", 0)
            else: self.image, self.rect = LoadingTheImage("minusbutton.jpg", 0)
        
            self.position = (1130, 400)
            self.rect.center = self.position
            
            if self.rect.collidepoint(mX, mY) == 1 and click == 1 and roundEnd == 1:
                playClickSound()
                if bet > 5:
                    bet -= 5.0
                    if bet % 5 != 0:
                        while bet % 5 != 0:
                            bet += 1
                    
                click = 0
            
            return bet, click
         
#---------------------------initialization and logistics------------------------
    # This font is used to display text on the right-hand side of the screen
    textFont = pygame.font.Font(None, 28)

    # This sets up the background image, and its container rect
    background, backgroundRect = LoadingTheImage("blackjack2.jpg", 0)
    
    # cards is the sprite group that will contain sprites for the dealer's cards
    cards = pygame.sprite.Group()
    # playerCards will serve the same purpose, but for the player
    playerCards = pygame.sprite.Group()

#Instances of button sprites
    buttonPlus = plusButton()
    buttonMinus = minusButton()
    standButton = standButton()
    dealButton = dealButton()
    hitButton = hitButton()
    doubleButton = doubleButton()
    
    # This group containts the button sprites
    buttons = pygame.sprite.Group(buttonPlus, buttonMinus, hitButton, standButton, dealButton, doubleButton)

    # The 52 card deck is created
    deck = creatingTheDeck()
    # The dead deck will contain cards that have been discarded
    oldDeck = []

    # These are default values that will be changed later, but are required to be declared now
    # so that Python doesn't get confused
    playerHand, dealerHand, dCardPos, pCardPos = [],[],(),()
    mX, mY = 0, 0
    click = 0

    # The default funds start at $100.00, and the initial bet defaults to $10.00
    funds = 100.00
    bet = 10.00

    # This is a counter that counts the number of rounds played in a given session
    handsPlayed = 0

    # When the cards have been dealt, roundEnd is zero.
    #In between rounds, it is equal to one
    roundEnd = 1
    
    # firstTime is a variable that is only used once, to display the initial
    # message at the bottom, then it is set to zero for the duration of the program.
    firstTime = 1
    
#-----------------------------main game loops-----------------------------------
    while 1:
        screen.blit(background, backgroundRect)
        
        if bet > funds:
            # If you lost money, and your bet is greater than your funds, make the bet equal to the funds
            bet = funds
        
        if roundEnd == 1 and firstTime == 1:
            # When the player hasn't started. Will only be displayed the first time.
            displayFont = display(textFont, "Instructions: place your bet then click deal to start the game.")
            #titleFont = pygame.font.Font.render(textFont,"Click on the arrows to declare your bet, then deal to start the game.",1,(255,255,255))
            firstTime = 0
            
        # Show the blurb at the bottom of the screen, how much money left, and current bet    
        screen.blit(displayFont, (300,700))
        fundsFont = pygame.font.Font.render(textFont, "Funds: $%.2f" %(funds), 1, (255,255,0))
        screen.blit(fundsFont, (1030,300))
        betFont = pygame.font.Font.render(textFont, "Bet: $%.2f" %(bet), 1, (255,255,0))
        screen.blit(betFont, (1030,330))
        hpFont = pygame.font.Font.render(textFont, "Round: %i " %(handsPlayed), 1, (255,255,0))
        screen.blit(hpFont, (1030, 270))

        for event in pygame.event.get():
            if event.type == QUIT:
                sys.exit()
            elif event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    mX, mY = pygame.mouse.get_pos()
                    click = 1
            elif event.type == MOUSEBUTTONUP:
                mX, mY = 0, 0
                click = 0
            
        # Initial check for the value of the player's hand, so that his hand can be displayed and it can be determined
        # if the player busts or has blackjack or not
        if roundEnd == 0:
            # Stuff to do when the game is happening 
            playerValue = checkingHands(playerHand)
            dealerValue = checkingHands(dealerHand)
    
            if playerValue == 21 and len(playerHand) == 2:
                # If the player gets blackjack
                displayFont, playerHand, dealerHand, oldDeck, funds, roundEnd = blackJack(deck, oldDeck, playerHand, dealerHand, funds,  bet, cards, cardSprite)
                
            if dealerValue == 21 and len(dealerHand) == 2:
                # If the dealer has blackjack
                displayFont, playerHand, dealerHand, oldDeck, funds, roundEnd = blackJack(deck, oldDeck, playerHand, dealerHand, funds,  bet, cards, cardSprite)

            if playerValue > 21:
                # If player busts
                deck, playerHand, dealerHand, oldDeck, funds, roundEnd, displayFont = tooManyCards(deck, playerHand, dealerHand, oldDeck, funds, 0, bet, cards, cardSprite)
         
        #Update the buttons 
        #deal 
        deck, oldDeck, playerHand, dealerHand, dCardPos, pCardPos, roundEnd, displayFont, click, handsPlayed = dealButton.update(mX, mY, deck, oldDeck, roundEnd, cardSprite, cards, playerHand, dealerHand, dCardPos, pCardPos, displayFont, playerCards, click, handsPlayed)   
        #hit    
        deck, oldDeck, playerHand, pCardPos, click = hitButton.update(mX, mY, deck, oldDeck, playerHand, playerCards, pCardPos, roundEnd, cardSprite, click)
        #stand    
        deck, oldDeck, roundEnd, funds, playerHand, oldDeck, pCardPos,  displayFont  = standButton.update(mX, mY,   deck, oldDeck, playerHand, dealerHand, cards, pCardPos, roundEnd, cardSprite, funds, bet, displayFont)
        #double
        deck, oldDeck, roundEnd, funds, playerHand, oldDeck, pCardPos, displayFont, bet  = doubleButton.update(mX, mY,   deck, oldDeck, playerHand, dealerHand, playerCards, cards, pCardPos, roundEnd, cardSprite, funds, bet, displayFont)
        #Bet buttons
        bet, click = buttonPlus.update(mX, mY, bet, funds, click, roundEnd)
        bet, click = buttonMinus.update(mX, mY, bet, click, roundEnd)
        #draw them to the screen
        buttons.draw(screen)
        # If there are cards on the screen, draw them    
        if len(cards) is not 0:
            playerCards.update()
            playerCards.draw(screen)
            cards.update()
            cards.draw(screen)

        # Updates display
        pygame.display.flip()

if __name__ == "__main__":
    mainGame()
